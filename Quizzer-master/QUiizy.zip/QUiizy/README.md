# Quizer

## Simple quiz program made in C++

## Compilation

```
g++ src/main.cpp -Iinclude/ -std=c++17 -lstdc++fs -o quiz
```

or

```
mkdir build && cd build
cmake ../
make
```
